var express = require('express');
var router = express.Router();

var mongoose = require('mongoose');
require('../models/postModel');
require('../models/commentModel');

var PostModel = mongoose.model('PostModel');
var CommentModel = mongoose.model('CommentModel');

router.param('post', function(req, res, next, id) {
    var query = PostModel.findById(id);

    query.exec(function (err, post){
        if (err) { return next(err); }
        if (!post) { return next(new Error("can't find post")); }

        req.post = post;
        return next();
    });
});

router.route('/')
    .get(function(req,res){
        PostModel.find(function(err,posts){
            if(err)
                res.send(err);
            res.json(posts);
        });
    })
    .post(function(req,res){
        var postModel = new PostModel(req.body);
        postModel.save(function(err){
            if(err)
                res.send(err);
            res.send({message:'Post Added'});
        });
    });

router.route('/:post')
    .put(function(req,res){

        /*for(prop in req.body){
            req.post[prop]=req.body[prop];
        }*/

        req.post.title = req.body.title;
        req.post.link = req.body.link;

        req.post.save(function(err) {
            if (err)
                res.send(err);

            res.json({ message: 'post updated!' });
        });
    })

    .get(function(req,res){
        req.post.populate('comments', function(err, post) {
            res.json(post);
        });
    })

    .delete(function(req,res){
        var comments = req.post.comments;

        if (!comments || !Array.isArray(comments) || comments.length === 0)
            console.log('no comments found');
        else
        {
            comments.forEach( function (comment) {
               var commentId = comment + '';
               CommentModel.remove({ _id: commentId }, function(err) {
                 if (err) {
                    console.log( 'deleted failed! ' + err );
                 }
               });
            });
        };

        req.post.remove(function(err) {
            if (err)
                res.send(err);

            res.json({ message: 'Successfully deleted comments now!' });
        });
    });


router.put('/:post/upvote', function(req, res, next) {
    req.post.upvote(function(err, post){
        if (err) { return next(err); }

        res.json(post);
    });
});

router.route('/:post/comments')
    .delete(function(req,res){
        var comments = req.post.comments;

        if (!comments || !Array.isArray(comments) || comments.length === 0)
            console.log('no comments found');
        else
        {
            comments.forEach( function (comment) {
                var commentId = comment + '';
                CommentModel.remove({ _id: commentId }, function(err) {
                    if (err) {
                        console.log( 'deleted failed! ' + err );
                    }
                });
            });
        };
    })
    .post(function(req, res, next) {
        var comment = new CommentModel(req.body);
        comment.post = req.post;

        comment.save(function(err, comment){
            if(err){ return next(err); }

            req.post.comments.push(comment);
            req.post.save(function(err, post) {
                if(err){ return next(err); }

                res.json(comment);
            });
        });
    });

module.exports = router;
