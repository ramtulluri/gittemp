var express = require('express');
var router = express.Router();

var mongoose = require('mongoose');
require('../models/postModel');
require('../models/commentModel');

var PostModel = mongoose.model('PostModel');
var CommentModel = mongoose.model('CommentModel');

router.param('comment', function(req, res, next, id) {
    var query = CommentModel.findById(id);

    query.exec(function (err, comment){
        if (err) { return next(err); }
        if (!comment) { return next(new Error("can't find comment")); }

        req.comment = comment;
        return next();
    });
});

router.route('/:comment')
    .put(function(req,res){

        for(prop in req.body){
            req.comment[prop]=req.body[prop];
        }

        req.comment.save(function(err) {
            if (err)
                res.send(err);

            res.json({ message: 'comment updated!' });
        });
    })

    .get(function(req,res){
        res.json(req.comment);
    })

    .delete(function(req,res){
        req.comment.populate('post', function(err, comment) {
            post = comment.post;
            post.comments.pull(req.comment);
            post.save(function(err, post) {
                if(err){ return next(err); }
            });
        });

        req.comment.remove(function(err) {
            if (err)
                res.send(err);

            res.json({ message: 'Successfully deleted comments now!' });
        });

    });

module.exports = router;
